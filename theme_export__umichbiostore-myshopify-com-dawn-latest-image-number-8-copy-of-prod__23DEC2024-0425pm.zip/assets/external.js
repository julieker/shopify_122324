function letMeCallYou()
{
    alert("Bazinga!!!  you called letMeCallYou")
}



async function storeInputInMetafield(customerId, inputValue) {
  const shopifyAdminUrl = `https://${window.Shopify.shop}/admin/customers/${customerId}/metafields.json`;
  const metafieldData = {
    metafield: {
      namespace: "custom",
      key: "customerpickedshortcode",
      value: sessionStorage.getItem("theshortcodeused") 
      // Adjust if your metafield is a different type
    }
  };

  try {
    const response = await fetch(shopifyAdminUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Shopify-Access-Token': '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' 

// Replace with your actual key
      },
      body: JSON.stringify(metafieldData)
    });

    if (!response.ok) {
      throw new Error('Failed to store metafield');
    }

    const data = await response.json();
    console.log('Metafield updated:', data);
    ele5.style.display = "none";



  } catch (error) {
    console.error('Error updating metafield:', error);
  }

}